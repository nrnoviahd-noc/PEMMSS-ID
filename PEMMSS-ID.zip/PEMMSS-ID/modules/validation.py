import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
from models.risk_model import FEATURES, TARGET
from sklearn.base import clone


def leave_one_out_validation(model, df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for idx in df.index:
        train = df.drop(index=idx)
        test = df.loc[[idx]]
        fitted = clone(model)
        fitted.fit(train[FEATURES], train[TARGET])
        pred = float(fitted.predict(test[FEATURES])[0])
        rows.append({"site_id": test["site_id"].iloc[0], "observed": float(test[TARGET].iloc[0]), "predicted": pred})
    result = pd.DataFrame(rows)
    return result


def validation_metrics(result: pd.DataFrame) -> dict:
    return {
        "MAE": mean_absolute_error(result["observed"], result["predicted"]),
        "R2": r2_score(result["observed"], result["predicted"]),
    }
