import numpy as np
import pandas as pd
from models.risk_model import FEATURES, TARGET, fit_ridge


def bootstrap_prediction_intervals(model_factory=fit_ridge, df: pd.DataFrame = None, n_boot: int = 250, seed: int = 42):
    rng = np.random.default_rng(seed)
    predictions = []
    for _ in range(n_boot):
        sample_idx = rng.integers(0, len(df), len(df))
        sample = df.iloc[sample_idx]
        model = model_factory(sample)
        predictions.append(model.predict(df[FEATURES]))
    arr = np.vstack(predictions)
    return pd.DataFrame({
        "site_id": df["site_id"].values,
        "prediction_mean": arr.mean(axis=0),
        "prediction_lower_95": np.quantile(arr, 0.025, axis=0),
        "prediction_upper_95": np.quantile(arr, 0.975, axis=0),
    })
