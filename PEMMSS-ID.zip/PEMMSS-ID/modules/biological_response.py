import pandas as pd


def add_biological_response(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    # Higher richness represents a stronger observed biological condition.
    # This index is deliberately descriptive and is not a toxicity threshold.
    min_r = out["species_richness"].min()
    max_r = out["species_richness"].max()
    out["biological_condition"] = (out["species_richness"] - min_r) / (max_r - min_r)
    out["biological_stress"] = 1 - out["biological_condition"]
    return out
