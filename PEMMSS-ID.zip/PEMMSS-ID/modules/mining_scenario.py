from pathlib import Path
import pandas as pd


def load_scenarios(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"scenario", "year", "mine_production_tonnes"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing scenario columns: {sorted(missing)}")
    return df


def pressure_index(df: pd.DataFrame, reference_production: float = 100_000) -> pd.DataFrame:
    """Create an illustrative relative pressure index.

    This is a placeholder scaling for workflow testing, not an emission factor.
    """
    out = df.copy()
    out["relative_mining_pressure"] = out["mine_production_tonnes"] / reference_production
    return out
