import numpy as np
import pandas as pd


def add_exposure_index(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    # Illustrative spatial exposure proxy only. Replace with transport modelling
    # or a validated spatial model when sufficient environmental data are available.
    distance_factor = 1 / (1 + out["distance_to_mine_km"])
    sediment_factor = out["sediment"] / out["sediment"].max()
    out["exposure_index"] = np.clip(
        0.7 * out["pollution_index"] + 0.3 * (distance_factor * sediment_factor),
        -10,
        10,
    )
    return out
