import pandas as pd

POLLUTANTS = ["Ni_mgkg", "Pb_mgkg", "Cd_mgkg"]


def load_observations(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"site_id", "latitude", "longitude", "distance_to_mine_km", "species_richness", *POLLUTANTS}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing observation columns: {sorted(missing)}")
    return df


def standardised_pollution_index(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in POLLUTANTS:
        mean = out[col].mean()
        std = out[col].std(ddof=0)
        out[f"z_{col}"] = (out[col] - mean) / std if std else 0.0
    zcols = [f"z_{c}" for c in POLLUTANTS]
    out["pollution_index"] = out[zcols].mean(axis=1)
    return out
