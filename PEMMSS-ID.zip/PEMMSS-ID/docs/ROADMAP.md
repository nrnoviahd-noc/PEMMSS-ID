# Development roadmap

## v0.1

- Indonesian scenario adapter
- synthetic test data
- pollution and biological-response workflow

## v0.2

- curated Indonesian observations
- source metadata
- explicit confounder assessment
- model comparison

## v0.3

- spatial prediction
- GIS layers
- spatial cross-validation

## v0.4

- uncertainty propagation
- sensitivity analysis
- independent-site validation

## v1.0

- proof-of-concept for one Indonesian coastal mining region
- reproducible workflow
- documented limitations

## v2.0

- independent second-region validation
- monitoring-priority prototype
- decision-support interface
