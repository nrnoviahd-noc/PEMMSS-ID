# Model scope

PEMMSS-ID is designed as a staged research framework rather than a finished national prediction system.

## Layer 1: mining scenario

The upstream PEMMSS model can provide mine-development or production scenarios. This repository currently uses a small CSV adapter with illustrative production values.

## Layer 2: environmental pressure

Future work should replace the illustrative pressure index with documented relationships between mining activity, waste generation, runoff, sediment mobilisation, and contaminant release.

## Layer 3: exposure

Future work should incorporate hydrodynamics, sediment transport, river connectivity, bathymetry, rainfall/runoff, and other variables where data permit.

## Layer 4: biological response

Potential endpoints include species richness, abundance, community composition, tissue concentrations, or validated bioindicator responses. The appropriate endpoint must be selected according to the available observations and research question.

## Layer 5: ecological risk

Risk should distinguish measured exposure, predicted exposure, biological effects, uncertainty, and regulatory interpretation. Regulatory thresholds should never be inserted into this prototype without documenting their jurisdiction, endpoint, units, and applicability.

## Validation

Spatially separated validation is preferred once enough independent locations are available. Leave-one-location-out validation in the current prototype is only a computational demonstration.
