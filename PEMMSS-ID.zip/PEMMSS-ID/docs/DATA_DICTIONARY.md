# Data dictionary

| Field | Meaning | Current status |
|---|---|---|
| site_id | Observation site identifier | Synthetic |
| latitude | Latitude | Synthetic |
| longitude | Longitude | Synthetic |
| distance_to_mine_km | Distance to mine | Synthetic |
| sediment | Relative sediment variable | Synthetic |
| Ni_mgkg | Nickel concentration | Synthetic |
| Pb_mgkg | Lead concentration | Synthetic |
| Cd_mgkg | Cadmium concentration | Synthetic |
| salinity | Salinity | Synthetic |
| temperature | Temperature | Synthetic |
| species_richness | Observed species richness | Synthetic |

Before publication, every real dataset should add source, sampling date, analytical method, unit, detection limit, and quality-control metadata.
