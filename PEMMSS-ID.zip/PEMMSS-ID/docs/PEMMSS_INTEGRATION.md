# PEMMSS integration plan

The preferred integration is an adapter rather than a rewrite of the upstream model.

```text
PEMMSS output
     ↓
scenario adapter
     ↓
scenario, year, mine_production_tonnes
     ↓
PEMMSS-ID environmental modules
```

The adapter should preserve the original PEMMSS output and record the upstream model version, input scenario, and execution date. This allows the environmental analysis to be rerun when the mining scenario changes.
