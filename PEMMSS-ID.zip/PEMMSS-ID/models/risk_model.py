import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

FEATURES = ["Ni_mgkg", "Pb_mgkg", "Cd_mgkg", "distance_to_mine_km", "sediment", "salinity", "temperature"]
TARGET = "biological_stress"


def fit_ridge(df: pd.DataFrame):
    model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
    model.fit(df[FEATURES], df[TARGET])
    return model


def predict(model, df: pd.DataFrame) -> pd.Series:
    return pd.Series(model.predict(df[FEATURES]), index=df.index, name="predicted_stress")
