from pathlib import Path
import pandas as pd
from modules.pollution import load_observations, standardised_pollution_index
from modules.biological_response import add_biological_response

ROOT = Path(__file__).resolve().parents[1]


def test_observation_pipeline():
    df = load_observations(ROOT / "data/raw/synthetic_coastal_observations.csv")
    df = standardised_pollution_index(df)
    df = add_biological_response(df)
    assert len(df) == 10
    assert "pollution_index" in df
    assert "biological_stress" in df
