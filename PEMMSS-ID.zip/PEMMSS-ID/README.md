# PEMMSS-ID

## Indonesian Nickel Mining Scenario and Coastal Ecological Risk Prototype

PEMMSS-ID is a research prototype for exploring how nickel-mining development scenarios can be connected to coastal pollution and ecological-risk assessment in Indonesia.

This repository is intentionally modular. The original PEMMSS model remains a separate upstream component. This project does **not** claim that PEMMSS directly predicts pollution concentrations or ecological risk. Instead, it provides a transparent framework for connecting mining scenarios with environmental observations, biological responses, spatial prediction, validation, and uncertainty analysis.

### Research concept

```text
Mining scenario
      ↓
Mining / production pressure
      ↓
Pollution observations
      ↓
Environmental exposure
      ↓
Biological response
      ↓
Ecological risk
      ↓
Spatial prediction + uncertainty
      ↓
Monitoring priority
```

### Current status

This is a proof-of-concept scaffold. The included dataset is **synthetic placeholder data** created only to test the computational workflow. It must not be interpreted as measurements from Kabaena, Obi, Raja Ampat, or any other Indonesian location.

The model structure is designed to be replaced with curated Indonesian observations as the research develops.

## Repository structure

```text
PEMMSS-ID/
├── data/
│   ├── raw/
│   └── processed/
├── input_files/
│   ├── mining_scenarios.csv
│   └── pollutant_parameters.csv
├── modules/
│   ├── mining_scenario.py
│   ├── pollution.py
│   ├── exposure.py
│   ├── biological_response.py
│   ├── risk_assessment.py
│   ├── validation.py
│   └── uncertainty.py
├── models/
│   └── risk_model.py
├── gis/
│   └── mapping.py
├── notebooks/
├── outputs/
├── tests/
├── run_prototype.py
├── requirements.txt
└── README.md
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run_prototype.py
```

On Windows, activate the environment with `.venv\\Scripts\\activate`.

The command creates example scenario, prediction, validation, and uncertainty outputs in `outputs/`.

## What the prototype does

1. Reads a mining-development scenario.
2. Converts scenario production into a clearly labelled **illustrative pressure index**.
3. Combines pollution observations with environmental predictors.
4. Estimates ecological response from the supplied observations.
5. Fits a simple prediction model.
6. Performs leave-one-location-out validation for the prototype dataset.
7. Produces prediction intervals through repeated bootstrap resampling.
8. Calculates a transparent risk index and exports a table suitable for GIS mapping.

The pressure calculation and risk index are deliberately simple placeholders. They are not emission factors, regulatory thresholds, or validated ecological relationships.

## Connecting the original PEMMSS model

The upstream PEMMSS project evaluates mine development, mineral exploration, and co-product recovery needed to meet primary demand over time. Its current repository uses CSV scenario inputs and produces scenario outputs. See the upstream project for the original model, documentation, license, and citation requirements.

PEMMSS-ID should consume an exported scenario table rather than modifying the scientific logic of the upstream model prematurely. A future adapter can map PEMMSS outputs into `input_files/mining_scenarios.csv`.

Expected adapter output:

```text
scenario,year,mine_production_tonnes
baseline,2030,100000
high_demand,2030,140000
...
```

## Data policy

When replacing the synthetic dataset with Indonesian observations:

- retain original source and citation metadata;
- preserve measurement units;
- document detection limits and missing values;
- distinguish measured concentrations from modelled values;
- record sampling date and coordinates where appropriate;
- do not mix incompatible analytical methods without documenting harmonisation;
- keep a clear distinction between observations, assumptions, and predictions.

## Planned scientific development

The intended progression is:

**v0.1**: scenario and pollution-data integration  
**v0.2**: ecological response modelling  
**v0.3**: spatial prediction  
**v0.4**: spatial cross-validation and uncertainty  
**v1.0**: proof-of-concept for one Indonesian coastal mining region  
**v2.0**: independent validation in a second region and decision-support prototype

## Important limitation

This repository is a methodological prototype, not a regulatory decision-support system. It should not be used to classify actual Indonesian sites as safe, unsafe, contaminated, or ecologically damaged until the models, input data, uncertainty estimates, and independent validation have been scientifically established.

## Upstream PEMMSS attribution

PEMMSS-ID is inspired by and designed to interface with the Primary Exploration, Mining and Metal Supply Scenario (PEMMSS) model by Northey and colleagues. The original PEMMSS repository and its BSD 3-Clause licence should be consulted before incorporating or redistributing its source code.

Suggested citation for the upstream model:

Northey, S.A., Klose, S., Pauliuk, S., Yellishetty, M., & Giurco, D. (2023). Primary Exploration, Mining and Metal Supply Scenario (PEMMSS) model: Towards a stochastic understanding of the mineral discovery, mine development and co-product recovery requirements to meet demand in a low-carbon future. *Resources, Conservation & Recycling Advances*, 17, 200137. https://doi.org/10.1016/j.rcradv.2023.200137
