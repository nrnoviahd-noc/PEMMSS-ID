import pandas as pd


def export_mapping_table(df: pd.DataFrame, path: str):
    cols = [c for c in ["site_id", "latitude", "longitude", "risk_index", "risk_uncertainty"] if c in df.columns]
    df[cols].to_csv(path, index=False)
