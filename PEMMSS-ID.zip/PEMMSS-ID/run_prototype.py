from pathlib import Path
import pandas as pd
from modules.mining_scenario import load_scenarios, pressure_index
from modules.pollution import load_observations, standardised_pollution_index
from modules.exposure import add_exposure_index
from modules.biological_response import add_biological_response
from models.risk_model import fit_ridge, predict
from modules.validation import leave_one_out_validation, validation_metrics
from modules.uncertainty import bootstrap_prediction_intervals

ROOT = Path(__file__).resolve().parent
SCENARIO_FILE = ROOT / "input_files" / "mining_scenarios.csv"
OBS_FILE = ROOT / "data" / "raw" / "synthetic_coastal_observations.csv"
OUT = ROOT / "outputs"


def main():
    scenarios = pressure_index(load_scenarios(SCENARIO_FILE))
    observations = load_observations(OBS_FILE)
    observations = standardised_pollution_index(observations)
    observations = add_exposure_index(observations)
    observations = add_biological_response(observations)

    # The first prototype uses a descriptive risk index, then tests a predictive model.
    observations["risk_index"] = observations["exposure_index"] * (0.5 + observations["biological_stress"])

    model = fit_ridge(observations)
    observations["predicted_stress"] = predict(model, observations)

    validation = leave_one_out_validation(model, observations)
    metrics = validation_metrics(validation)
    uncertainty = bootstrap_prediction_intervals(fit_ridge, observations)

    OUT.joinpath("scenarios").mkdir(parents=True, exist_ok=True)
    OUT.joinpath("predictions").mkdir(parents=True, exist_ok=True)
    OUT.joinpath("validation").mkdir(parents=True, exist_ok=True)
    OUT.joinpath("uncertainty").mkdir(parents=True, exist_ok=True)
    OUT.joinpath("risk_maps").mkdir(parents=True, exist_ok=True)

    scenarios.to_csv(OUT / "scenarios" / "scenario_pressure.csv", index=False)
    observations.to_csv(OUT / "predictions" / "prototype_predictions.csv", index=False)
    validation.to_csv(OUT / "validation" / "leave_one_out_predictions.csv", index=False)
    uncertainty.to_csv(OUT / "uncertainty" / "bootstrap_intervals.csv", index=False)
    pd.DataFrame([metrics]).to_csv(OUT / "validation" / "metrics.csv", index=False)

    mapping = observations[["site_id", "latitude", "longitude", "risk_index"]].copy()
    mapping = mapping.merge(uncertainty, on="site_id")
    mapping["risk_uncertainty"] = mapping["prediction_upper_95"] - mapping["prediction_lower_95"]
    mapping.to_csv(OUT / "risk_maps" / "prototype_risk_map.csv", index=False)

    print("PEMMSS-ID prototype completed.")
    print(f"Validation MAE: {metrics['MAE']:.4f}")
    print(f"Validation R2: {metrics['R2']:.4f}")
    print(f"Outputs: {OUT}")


if __name__ == "__main__":
    main()
